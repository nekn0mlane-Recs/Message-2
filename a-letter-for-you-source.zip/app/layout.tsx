import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "A Letter for You",
  description: "A little story about courage, honesty, and the possibility of us.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
