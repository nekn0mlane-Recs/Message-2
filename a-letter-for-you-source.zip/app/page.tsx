"use client";
import { useEffect, useState } from "react";

const HER_NAME = "You"; // Change this to her name
const YOUR_NAME = "Someone who truly cares"; // Change this to your name
const chapters = [
  { eyebrow:"Before anything else", title:`Hey, ${HER_NAME}…`, lines:["I made this because some feelings deserve more than a hurried message.","There is something I have been trying to say—honestly, gently, and without hiding behind fear."], button:"Walk with me" },
  { eyebrow:"Chapter one · Us", title:"Somewhere along the way…", lines:["Our ordinary conversations stopped feeling ordinary to me.","Your presence became something I looked forward to. Your happiness began to matter to me. And without planning it, the word ‘us’ started living quietly in my thoughts."], button:"There’s more" },
  { eyebrow:"Chapter two · The quiet truth", title:"I know you’ve been wondering.", lines:["You may be asking what is happening between us. The truth is, I have been wondering too—probably more than I know how to explain.","If I sometimes seem uncertain or distant, it is not because I do not want you. It is because what I feel is real enough to scare me."], button:"Let me be honest" },
  { eyebrow:"Chapter three · The scary part", title:"Yes, I am afraid.", lines:["I am scared of making mistakes. I am scared that I will not always know the right thing to say or do.","Commitment means placing something precious in another person’s hands. It means being vulnerable—and that is something I am still learning how to do."], button:"But fear isn’t the ending" },
  { eyebrow:"Chapter four · My choice", title:"Even with that fear, I am willing.", lines:["I am willing to try. To communicate. To grow with you.","I am willing to choose you—not only when everything feels exciting and easy, but also when things become confusing, uncertain, or difficult.","I cannot promise perfection. But I can promise honesty, effort, and that I will never treat your feelings like a game."], button:"One last page" },
  { eyebrow:"The page I hope we write together", title:"So, what is happening to us?", lines:["Maybe we are standing at the beginning of something beautiful.","I am scared—but I am here. I am uncertain—but I am sincere. And if you will let me, I want to discover where this ‘us’ can go.","You do not need to answer everything today. I only want you to know that you matter to me—more than you probably realize."], button:"Open my heart" },
];

export default function Home() {
  const [started,setStarted]=useState(false), [chapter,setChapter]=useState(0), [finale,setFinale]=useState(false), [transitioning,setTransitioning]=useState(false);
  const [popup,setPopup]=useState(""), [hearts,setHearts]=useState<{id:number,x:number,y:number,s:string}[]>([]), [soundOn,setSoundOn]=useState(true);
  const littleTruths=["You make ordinary moments feel special.","This part took courage to write.","No games. Only honesty.","Still here. Still choosing courage.","This is what my heart has been trying to say."];
  function chime(note=523){if(!soundOn)return;const AudioContextClass=window.AudioContext||(window as typeof window & {webkitAudioContext:typeof AudioContext}).webkitAudioContext;if(!AudioContextClass)return;const ctx=new AudioContextClass(),osc=ctx.createOscillator(),gain=ctx.createGain();osc.type="sine";osc.frequency.value=note;gain.gain.setValueAtTime(.0001,ctx.currentTime);gain.gain.exponentialRampToValueAtTime(.055,ctx.currentTime+.02);gain.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+.5);osc.connect(gain);gain.connect(ctx.destination);osc.start();osc.stop(ctx.currentTime+.52)}
  function showTruth(){setPopup(littleTruths[Math.min(chapter,littleTruths.length-1)]);setTimeout(()=>setPopup(""),2600);chime(659)}
  function next(){ if(transitioning)return; chime(523+chapter*28); if(chapter===chapters.length-1){setFinale(true);return} setTransitioning(true);setTimeout(()=>{setChapter(c=>c+1);setTransitioning(false)},420) }
  useEffect(()=>{const key=(e:KeyboardEvent)=>{if(e.key==="ArrowRight"&&started&&!finale)next()};window.addEventListener("keydown",key);return()=>window.removeEventListener("keydown",key)});
  function restart(){setFinale(false);setChapter(0);setStarted(false)}
  function makeHeart(e:React.PointerEvent<HTMLElement>){const id=Date.now()+Math.random();setHearts(h=>[...h.slice(-10),{id,x:e.clientX,y:e.clientY,s:["♥","♡","✦"][Math.floor(Math.random()*3)]}]);setTimeout(()=>setHearts(h=>h.filter(v=>v.id!==id)),1300)}
  const current=chapters[chapter], progress=((chapter+1)/chapters.length)*100;
  return <main className="story-shell" onPointerDown={makeHeart}>
    <div className="ambient ambient-one"/><div className="ambient ambient-two"/>
    <div className="love-orbit orbit-one" aria-hidden="true"><span>♥</span></div><div className="love-orbit orbit-two" aria-hidden="true"><span>♡</span></div>
    <div className="stars" aria-hidden="true">{Array.from({length:22}).map((_,i)=><i key={i}/>)}</div>
    {hearts.map(h=><span key={h.id} className="click-heart" style={{left:h.x,top:h.y}}>{h.s}</span>)}
    {popup&&<div className="love-popup" role="status"><span>♥</span>{popup}</div>}
    {started&&<button className="sound-toggle" onClick={(e)=>{e.stopPropagation();setSoundOn(v=>!v)}} aria-label={soundOn?"Turn gentle sounds off":"Turn gentle sounds on"}>{soundOn?"♫":"♩"}</button>}
    {!started ? <section className="envelope-stage">
      <p className="whisper">A tiny story, written for one person.</p>
      <button className="envelope" onClick={()=>{setStarted(true);chime(440);setTimeout(()=>chime(659),160)}} aria-label="Open the letter"><span className="letter-peek">A story of us</span><span className="envelope-flap"/><span className="seal">♥</span><span className="envelope-label">For {HER_NAME}</span></button>
      <p className="tap-hint">Tap the envelope to begin</p>
    </section> : finale ? <section className="finale-card">
      <div className="heart-rings"><i/><i/><div className="heart-pulse">♥</div></div><p className="eyebrow">No pressure. Just the truth.</p>
      <h1>If your heart is willing too,<br/><em>let’s take it one honest step at a time.</em></h1>
      <p className="final-note">Whatever your answer may be, thank you for reading the words I was once too afraid to say.</p>
      <div className="signature"><span>With courage and care,</span><strong>{YOUR_NAME}</strong></div>
      <button className="ghost-button" onClick={restart}>Read our story again</button>
    </section> : <section className={`chapter-card ${transitioning?"leaving":"entering"}`}>
      <header className="story-header"><span>Our little story</span><button className="secret-button" onClick={showTruth}>a tiny secret ♡</button><span>{String(chapter+1).padStart(2,"0")} / {String(chapters.length).padStart(2,"0")}</span></header>
      <div className="progress"><span style={{width:`${progress}%`}}/></div>
      <div className="heart-steps" aria-label={`Story progress: ${chapter+1} of ${chapters.length}`}>{chapters.map((_,i)=><i key={i} className={i<=chapter?"filled":""}>{i<=chapter?"♥":"♡"}</i>)}</div>
      <div className="chapter-content"><p className="eyebrow">{current.eyebrow}</p><h1>{current.title}</h1><div className="prose">{current.lines.map((line,i)=><p key={i}>{line}</p>)}</div></div>
      <footer className="story-footer"><button className="back-button" onClick={()=>setChapter(c=>Math.max(0,c-1))} disabled={chapter===0}>← Back</button><button className="continue-button" onClick={next}>{current.button} <span>→</span></button></footer>
    </section>}
  </main>
}
